from tyype.inty import *
from tyype.floaty import *
from tyype.datey import *